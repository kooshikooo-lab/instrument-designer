__version__ = "2.0.0"
__app_name__ = "Instrument Designer"
